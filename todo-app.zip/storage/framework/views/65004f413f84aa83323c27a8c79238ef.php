<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl">My To-Do List ✅</h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-2xl mx-auto bg-white p-4 shadow rounded">
            <!-- Add Task -->
            <form id="taskForm" class="mb-4">
                <?php echo csrf_field(); ?>
                <textarea name="title" class="border rounded w-full px-2 py-1 mb-2" placeholder="New task..." required></textarea>
                <button type="submit"
                    class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded w-full">
                    ➕ Add Task
                </button>
            </form>

            <!-- Task List -->
            <ul id="taskList">
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-id="<?php echo e($task->id); ?>" class="flex justify-between items-center mb-2 border-b py-1">
                        <div>
                            <span class="<?php echo e($task->is_completed ? 'line-through text-gray-500' : ''); ?>">
                                <?php echo e($task->title); ?>

                            </span>
                            <small class="block text-xs text-gray-500">
                                Start: <?php echo e($task->start_time ?? '-'); ?>

                                | Done: <?php echo e($task->done_time ?? '-'); ?>

                            </small>
                        </div>
                        <div class="flex space-x-2">
                            <button class="toggleBtn text-green-600 text-sm">
                                <?php echo e($task->is_completed ? 'Undo' : 'Mark Done'); ?>

                            </button>
                            <button class="deleteBtn text-red-500 text-sm">Delete</button>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Add Task (AJAX without reload)
        $('#taskForm').submit(function(e) {
            e.preventDefault();

            $.post("<?php echo e(route('tasks.store')); ?>", $(this).serialize(), function(response) {
                if (response.success) {
                    let task = response.task;

                    // Append new task to list
                    $('#taskList').prepend(`
                    <li data-id="${task.id}" class="flex justify-between items-center mb-2 border-b py-1">
                        <div>
                            <span>${task.title}</span>
                            <small class="block text-xs text-gray-500">
                                Start: ${task.start_time} | Done: -
                            </small>
                        </div>
                        <div class="flex space-x-2">
                            <button class="toggleBtn text-green-600 text-sm">Mark Done</button>
                            <button class="deleteBtn text-red-500 text-sm">Delete</button>
                        </div>
                    </li>
                `);

                    // Clear textarea
                    $('#taskForm textarea').val('');
                }
            });
        });

        // Toggle Complete (AJAX without reload)
        $(document).on('click', '.toggleBtn', function(e) {
            e.preventDefault();
            let li = $(this).closest('li');
            let id = li.data('id');
            let btn = $(this);

            $.ajax({
                url: '/tasks/' + id,
                type: 'PUT',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        let task = response.task;

                        // Update text style
                        let span = li.find('span');
                        if (task.is_completed) {
                            span.addClass('line-through text-gray-500');
                            btn.text('Undo');
                        } else {
                            span.removeClass('line-through text-gray-500');
                            btn.text('Mark Done');
                        }

                        // Update times
                        li.find('small').text(
                            `Start: ${task.start_time ?? '-'} | Done: ${task.done_time ?? '-'}`);
                    }
                }
            });
        });

        // Delete Task (AJAX without reload)
        $(document).on('click', '.deleteBtn', function(e) {
            e.preventDefault();
            let li = $(this).closest('li');
            let id = li.data('id');

            $.ajax({
                url: '/tasks/' + id,
                type: 'DELETE',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        li.remove(); // remove from DOM
                    }
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\todo-app\resources\views/tasks/index.blade.php ENDPATH**/ ?>